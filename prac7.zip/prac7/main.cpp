
#include "PrefixMatcher.h"

#include <iostream>
#include <string>
using namespace std;

int main() {
    PrefixMatcher p;

    p.insert("101001", 1);
    p.insert("101101", 2);
    p.insert("1010101111", 3);
    p.insert("10101100", 4);
    p.insert("1001", 5);

    cout << p.selectRouter("10") << endl;
}